#!/usr/bin/env python
# coding: utf-8
# Our the dataset:
•Images and METS/ALTO (positional XML)
•Also available as plain text
•11,577,467 words
•OCR: no clean-up
•Also occasional illustrations within pages
Because they are scanning newspaper documents, most of them have spelling errors or garbled characters, or mistakes in keywords extraction and matching (classification)
So my csv data is basically sorted out from txt. I selected a newspaper from 1869-1880 and selected some keywords such as price, gender, newspaper theme and other information for data analysis.
# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
data = pd.read_csv('re-database.csv')
data


# In[3]:


data.info()


# In[4]:


#How many rows are in the dataset after cleaning?
data.shape[0]


# In[18]:


# What is the largest price?
size = data.iloc[:,1]
print (size.max())


# In[5]:


# Choose a newspaper from 1869? (Because each year in the data represents a newspaper, the newspaper in 1869)
data.loc[data['Year'] == 1869]


# In[6]:


# View the deduplication item of this project name
data['Topic'].unique()


# In[7]:


#Information about ‘Year’ in the subdata
subdata1=data["Year"].unique()
print(subdata1)


# In[22]:


#Information about ‘Topic’ in the subdata
subdata2=data.loc[:,'Topic']
print(subdata2)


# In[8]:


# What Price of the Year was the largest expensive?
data1 = data[data["Price"] == data["Price"].max()][["Year"]]
print(data1['Year'].unique())


# In[9]:


# What content has been published repeatedly over the years?
from collections import Counter
Topics = Counter(data['Topic'])
Topics_sort = Topics.most_common()
[item[0] for item in Topics_sort if item[1] > 1]


# In[25]:


# How many times does each content appear?
Topics_sort


# In[14]:


# What is the gender distribution in these years
import seaborn as sns
chart = sns.countplot(x = "Year", data=data, hue="Gender")
chart.set_title('Gender distribution')
plt.show()
#Only a handful of female authors’ articles were published in newspapers, They were in 1869, 1870 and 1877.


# In[27]:


# How often is the newspaper published?
data_period = data['Period'].value_counts().sort_index().plot.bar(
    figsize=(4, 8),
    color='pink',
    fontsize=15 )
data_period.set_title("Distribution of periods", fontsize=15)
sns.despine(top=True, right=True)
plt.tight_layout()
#So weekly publication frequency is highest


# In[12]:


# What is the percentage of the author’s gender in twelve years？
y=data["Gender"].value_counts()
plt.pie(y,
        labels=['Male','Female'],
        autopct='%.2f%%'
       )
plt.title("Percentage of author’s gender")
plt.show()
#Most authors are male.


# In[15]:


# Changes in the price of newspapers in recent years?
chart = sns.lineplot(x="Year", y="Price",data=data)
chart.set_title('Price trend')
plt.show()
#The price of newspapers stabilized at 2pence after 1875, and the highest price in 1872-1873 was 4pence，
#The overall price is on a downward trend


# Reflection:
# When I saw these databases, they were really huge and complicated, and many txts were garbled, which made me more patiently sort out the data I wanted and build my own database.
# But reading the Spiritualism newspaper is very interesting and very challenging!
# We are thinking about designing a website in the form of interactive music. nlp may become a good way to help us separate the keywords in the newspaper more quickly. Which themes and popular topics will appear repeatedly? How will it change over time? For example, in my data, I found that topics such as astrology, soul out of the body, and hypnosis were recurring. Does this explain the social trends and people's beliefs at the time?
# 
# I want to make a few hypotheses next:
# 1.In the data, I found that he went from monthly to semi-monthly and finally became a weekly newspaper, indicating that the number of newspapers has increased, and in reading I found that the publication of spiritual newspapers has gradually expanded from the United Kingdom to Europe, the United States, and even Shanghai,China.
# Perhaps the subject of soul-calling has become popular, and more people want to learn about this mysterious field.
# 2.The decline in the price of newspapers may be due to the increase in circulation. Lowering the price can result in small profits but quick turnover, so that more people are willing to keep ordering. I want to ask the owner of the data for more information about the price and publication volume.
# 3.Gender differences are the most curious part of me, because women are dominant in mental sports, but almost 90% of newspaper article authors are men. I need more data to analysis: Whether even though female psychics have the ability to call upon souls, men still have the most right to speak in the real world, and they can choose what content and information to publish.
